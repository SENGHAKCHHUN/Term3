const randomAuthor = () => {
    // TODO: random author name
    let array = []
    for (let name of tr) {
        array.push(name.firstElementChild.nextElementSibling.textContent)
    }
    let index = Math.floor(Math.random() * array.length);
    showTitle.textContent = array[index]

}

// search movie title
const searchMovieTitle = () => {
    // TODO: search movie by title
    let data = searchText.value;
    let listMovie = [];
    for (let movie of tr) {
        listMovie.push(movie.firstElementChild.textContent)
    }
    // console.log(listMovie)
    for (let list of listMovie) {
        // console.log(list)
        if (list.toLocaleLowerCase().includes(data.toLocaleLowerCase())) {
        
            
        } else {
            // console.log(data)
        }
    }
}



// Main
const tr = document.querySelectorAll('tbody tr');
const searchText = document.querySelector('#search');
const showTitle = document.querySelector('h1');
// TODO: Add event listeners on input search
searchText.addEventListener('input', searchMovieTitle)

// TODO: call randomAuthor function every 1000 milliseconds
setInterval(randomAuthor, 1000)