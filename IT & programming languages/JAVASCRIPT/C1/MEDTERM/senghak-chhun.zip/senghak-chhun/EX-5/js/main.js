
// Remove row functions from the table
const removeRow = (event) => {
   // TODO: Remove row with confirmation message when click on remove button
   if (window.confirm('do you want to delte')){
       event.target.closest('tr').remove()
   }
}

// View user information in list 
const viewUser = (event) => {
    // TODO: View user information in list by click on view button
    let tr = event.target.closest('tr')

    let ul = document.createElement('ul')
    for (let td of tr.children){
        let li = document.createElement('li');
        li.textContent = td.textContent
        ul.appendChild(li);
    }
    ul.lastElementChild.remove()
    leftBox.appendChild(ul)
}

// Main
const leftBox = document.querySelector('.left-box');
const btnViews = document.querySelectorAll('.view');
const btnRemoves = document.querySelectorAll('.remove');
// console.log(btnViews)
// TODO: Add Event listeners to remove button


// TODO: Add event listeners to view button
for (let del of btnRemoves){
    del.addEventListener('click',removeRow)
}
for (let btn of btnViews){
    // console.log(btn)
    btn.addEventListener('click',viewUser)
}